Source for Python package
